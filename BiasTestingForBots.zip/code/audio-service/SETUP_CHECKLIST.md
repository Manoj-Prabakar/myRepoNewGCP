# Quick Setup Checklist for Google TTS

## Required Items to Update in `BOT-TO-TEST-CONFIGURATION-INFO.txt`

### 1. **CREDS_PATH** (Most Important for TTS)
```
CREDS_PATH = "path/to/your/service-account-key.json"
```
- **What**: Path to your Google Cloud service account JSON key file
- **Where to get it**: 
  - Google Cloud Console → IAM & Admin → Service Accounts
  - Create or select a service account
  - Create a key (JSON format) and download it
- **Example**: `CREDS_PATH = "C:\Users\YourName\Downloads\my-service-account-key.json"`
- **Or relative**: `CREDS_PATH = "./credentials/service-account-key.json"`

### 2. **PROJECT_ID** (Required by config loader)
```
PROJECT_ID = "your-actual-project-id"
```
- **What**: Your Google Cloud Project ID
- **Where to find**: Google Cloud Console → Project dropdown (top bar)
- **Example**: `PROJECT_ID = "my-test-project-12345"`

### 3. **LOCATION** (Required by config loader)
```
LOCATION = "us-central1"
```
- **What**: Your Google Cloud region
- **Common values**: `"us-central1"`, `"us-east1"`, `"global"`, `"asia-southeast1"`
- **Keep default if unsure**: `LOCATION = "us-central1"`

### 4. **AGENT_ID** (Required by config loader, but not used for TTS-only testing)
```
AGENT_ID = "your-dialogflow-agent-id"
```
- **What**: Your Dialogflow CX Agent ID (UUID format)
- **Where to find**: Dialogflow CX Console → Agent Settings → Agent ID
- **Example**: `AGENT_ID = "12345678-abcd-1234-abcd-123456789abc"`
- **Note**: Not needed if you're only testing TTS with `--skip-testing`

## Additional Setup Steps

### 5. Enable Text-to-Speech API
- Go to: [Google Cloud Console - APIs & Services](https://console.cloud.google.com/apis/library)
- Search for "Cloud Text-to-Speech API"
- Click "Enable"

### 6. Grant Service Account Permissions
- Go to: Google Cloud Console → IAM & Admin → Service Accounts
- Select your service account
- Ensure it has "Cloud Text-to-Speech API User" role (or at minimum, the API is enabled for the project)

## Minimal Test Configuration

If you just want to test TTS generation (skip Dialogflow testing):

**Minimum required updates:**
1. ✅ `CREDS_PATH` - Must point to valid service account JSON file
2. ✅ `PROJECT_ID` - Any valid project ID (can be dummy for TTS-only)
3. ✅ `LOCATION` - Any valid location (e.g., "us-central1")
4. ✅ `AGENT_ID` - Any UUID format (can be dummy for TTS-only)

**Then run:**
```powershell
python main.py sample-utterance.xlsx --limit 1 --skip-testing
```

## Quick Verification

After updating the config file, verify:

```powershell
# Check if credentials file exists (update path from your config)
Test-Path "your\path\to\service-account-key.json"

# View your config values
Select-String -Path "BOT-TO-TEST-CONFIGURATION-INFO.txt" -Pattern "CREDS_PATH|PROJECT_ID|LOCATION|AGENT_ID"
```

## Example Complete Config (Minimal)

```txt
PROJECT_ID = "my-test-project"
LOCATION = "us-central1"
AGENT_ID = "00000000-0000-0000-0000-000000000000"
CREDS_PATH = "C:\path\to\service-account-key.json"
FLOW_ID = ""
PAGE_ID = ""
START_WITH_GREETING = False
TTS_SERVICE = "google"
```

