# Where to Find Configuration Items in Google Cloud Console

## 1. PROJECT_ID ✅ (You already have this!)

**From your screenshot:**
- **Project ID:** `dialogflow-001-481218`

**Where to find it:**
- Google Cloud Console → Top bar (project dropdown)
- Or: Home page → Project info card (as shown in your screenshot)

**Update in config:**
```
PROJECT_ID = "dialogflow-001-481218"
```

---

## 2. LOCATION

**Where to find it:**
1. Go to [Dialogflow CX Console](https://dialogflow.cloud.google.com/)
2. Select your agent
3. Click on **⚙️ Settings** (gear icon) in the left sidebar
4. Look for **"Location"** or **"Region"** field
5. Common values: `us-central1`, `us-east1`, `global`, `asia-southeast1`

**Or check in Google Cloud Console:**
1. Go to: [Dialogflow CX Agents](https://console.cloud.google.com/dialogflow/cx/agents)
2. Click on your agent
3. Check the URL or agent details for location

**Update in config:**
```
LOCATION = "us-central1"  # or whatever location your agent uses
```

---

## 3. AGENT_ID

**Easiest way - From the URL:**
- When viewing your agent in Dialogflow CX Console, look at the browser address bar
- The URL will look like:
  `conversational-agents.cloud.google.com/projects/dialogflow-001-481218/locations/global/agents/379f4566-3a42-450e-83c3-0b5a5e019899/...`
- The part after `/agents/` and before the next `/` is your **Agent ID**
- In the example above: `379f4566-3a42-450e-83c3-0b5a5e019899`

**Alternative - From Agent Settings:**
1. In Dialogflow CX Console, click on **⚙️ Agent Settings** (gear icon) in the left sidebar
2. Look for **"Agent ID"** field (it's a UUID format)

**Update in config:**
```
AGENT_ID = "your-actual-agent-id-here"
```

---

## 4. CREDS_PATH (Service Account Key File)

**Step 1: Create or Select Service Account**
1. Go to: [IAM & Admin → Service Accounts](https://console.cloud.google.com/iam-admin/serviceaccounts?project=dialogflow-001-481218)
2. Click **"+ CREATE SERVICE ACCOUNT"** (or select existing one)
3. Fill in:
   - **Service account name:** e.g., `tts-service-account`
   - **Service account ID:** (auto-filled)
   - Click **"CREATE AND CONTINUE"**

**Step 2: Grant Permissions**
1. In **"Grant this service account access to project"**:
   - Click **"+ ADD ANOTHER ROLE"** to add multiple roles
   - **For Text-to-Speech**, search for one of these (try different searches):
     - Search: **"Text-to-Speech"** (with capital T and hyphen)
     - Search: **"Text to Speech"** (with spaces)
     - Look for: **"Cloud Text-to-Speech API User"** or **"Cloud Text-to-Speech User"**
     - If not found, try: **"Cloud Text-to-Speech Editor"** (more permissive)
   - **For Dialogflow**, search for:
     - **"Dialogflow API Client"** (you already have this selected)
   - Click **"CONTINUE"** → **"DONE"**

**Note:** If you can't find Text-to-Speech roles:
1. Make sure you've enabled the **Cloud Text-to-Speech API** first (see step 5 below)
2. Try searching without hyphens: **"Text to Speech"**
3. You can also grant permissions later by editing the service account

**Step 3: Create and Download Key**
1. Click on your newly created service account
2. Go to **"KEYS"** tab
3. Click **"ADD KEY"** → **"Create new key"**
4. Select **"JSON"** format
5. Click **"CREATE"**
6. The JSON file will download automatically

**Step 4: Save the File**
- Save it somewhere accessible, e.g.:
  - `C:\Users\YourName\Downloads\dialogflow-001-service-account-key.json`
  - Or in your project: `D:\projects\TestingForBots\audio-service\credentials\service-account-key.json`

**Update in config:**
```
CREDS_PATH = "C:\Users\YourName\Downloads\dialogflow-001-service-account-key.json"
# Or relative path:
CREDS_PATH = "./credentials/service-account-key.json"
```

---

## 5. Enable Text-to-Speech API

**Where to enable:**
1. Go to: [APIs & Services → Library](https://console.cloud.google.com/apis/library?project=dialogflow-001-481218)
2. Search for: **"Cloud Text-to-Speech API"**
3. Click on it
4. Click **"ENABLE"** button
5. Wait for it to enable (usually takes a few seconds)

**Verify it's enabled:**
- Go to: [APIs & Services → Enabled APIs](https://console.cloud.google.com/apis/dashboard?project=dialogflow-001-481218)
- You should see "Cloud Text-to-Speech API" in the list

---

## Quick Links for Your Project

Based on your project ID `dialogflow-001-481218`:

- **Service Accounts:** https://console.cloud.google.com/iam-admin/serviceaccounts?project=dialogflow-001-481218
- **APIs Library:** https://console.cloud.google.com/apis/library?project=dialogflow-001-481218
- **Dialogflow CX Agents:** https://console.cloud.google.com/dialogflow/cx/agents?project=dialogflow-001-481218
- **Dialogflow CX Console:** https://dialogflow.cloud.google.com/

---

## Summary Checklist

- [ ] **PROJECT_ID**: `dialogflow-001-481218` ✅ (from your screenshot)
- [ ] **LOCATION**: Find in Dialogflow CX → Settings
- [ ] **AGENT_ID**: Find in Dialogflow CX → Settings
- [ ] **CREDS_PATH**: Create service account → Download JSON key → Update path
- [ ] **Enable Text-to-Speech API**: APIs & Services → Enable

---

## Example Complete Config

After gathering all info:

```txt
PROJECT_ID = "dialogflow-001-481218"
LOCATION = "us-central1"
AGENT_ID = "your-actual-agent-id-from-dialogflow"
CREDS_PATH = "C:\path\to\downloaded-service-account-key.json"
FLOW_ID = ""
PAGE_ID = ""
START_WITH_GREETING = False
TTS_SERVICE = "google"
```

