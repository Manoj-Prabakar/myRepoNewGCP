# How to Grant Text-to-Speech Permissions to Service Account

## Option 1: Edit Existing Service Account (Recommended)

Since you already have service accounts, you can add the Text-to-Speech role to an existing one:

### Steps:

1. **Go to Service Accounts:**
   - From the Credentials page, click **"Manage service accounts"** link (top right of Service Accounts section)
   - Or go directly to: https://console.cloud.google.com/iam-admin/serviceaccounts?project=dialogflow-001-481218

2. **Select Your Service Account:**
   - Click on the service account you want to use (e.g., `dialogflow-service-account`)

3. **Go to Permissions Tab:**
   - Click on the **"PERMISSIONS"** tab at the top

4. **Grant Access:**
   - Click **"GRANT ACCESS"** button
   - In the "New principals" field, your service account email should already be there
   - Click **"Select a role"** dropdown
   - Search for: **"Text-to-Speech"** or **"Text to Speech"**
   - Select: **"Cloud Text-to-Speech API User"** (or "Cloud Text-to-Speech User")
   - Click **"SAVE"**

### Alternative Role Names to Look For:
- "Cloud Text-to-Speech API User" (preferred)
- "Cloud Text-to-Speech User"
- "Cloud Text-to-Speech Editor" (more permissive, but works)

---

## Option 2: Use IAM & Admin Directly

1. **Go to IAM & Admin:**
   - https://console.cloud.google.com/iam-admin/iam?project=dialogflow-001-481218

2. **Find Your Service Account:**
   - Look for your service account email in the list (e.g., `dialogflow-service-account@dialogflow-001-481218.iam.gserviceaccount.com`)

3. **Edit Permissions:**
   - Click the **pencil icon** (✏️) next to the service account
   - Click **"+ ADD ANOTHER ROLE"**
   - Search for: **"Text-to-Speech"**
   - Select: **"Cloud Text-to-Speech API User"**
   - Click **"SAVE"**

---

## Option 3: Create New Service Account with Permissions

If you prefer a new service account:

1. **Go to Service Accounts:**
   - https://console.cloud.google.com/iam-admin/serviceaccounts?project=dialogflow-001-481218
   - Click **"+ CREATE SERVICE ACCOUNT"**

2. **Fill Details:**
   - Service account name: `tts-service-account` (or any name)
   - Click **"CREATE AND CONTINUE"**

3. **Grant Permissions:**
   - Click **"+ ADD ANOTHER ROLE"**
   - Search for: **"Text-to-Speech"**
   - Select: **"Cloud Text-to-Speech API User"**
   - (Optional) Add **"Dialogflow API Client"** for Dialogflow testing
   - Click **"CONTINUE"** → **"DONE"**

4. **Create Key:**
   - Click on the newly created service account
   - Go to **"KEYS"** tab
   - Click **"ADD KEY"** → **"Create new key"**
   - Select **"JSON"**
   - Click **"CREATE"**
   - Save the downloaded JSON file

---

## Verify Permissions

After granting permissions, verify:

1. Go to your service account → **"PERMISSIONS"** tab
2. You should see:
   - ✅ **Cloud Text-to-Speech API User** (or similar)
   - ✅ **Dialogflow API Client** (if you added it)

---

## Quick Link

**Direct link to manage service accounts:**
https://console.cloud.google.com/iam-admin/serviceaccounts?project=dialogflow-001-481218

