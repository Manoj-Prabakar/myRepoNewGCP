# Testing Google TTS - Step by Step Guide

## Prerequisites Check

### 1. Install Dependencies
```powershell
cd audio-service
pip install -r requirements.txt
```

### 2. Verify Google TTS Library is Installed
```powershell
python -c "from google.cloud import texttospeech; print('Google TTS library is installed')"
```

### 3. Check Google Cloud Credentials
```powershell
# Option 1: Check if GOOGLE_APPLICATION_CREDENTIALS environment variable is set
$env:GOOGLE_APPLICATION_CREDENTIALS

# Option 2: Verify credentials file exists (update path as needed)
Test-Path "path\to\your\service-account-key.json"
```

### 4. Verify Configuration File
```powershell
# Check that TTS_SERVICE is set to "google" in BOT-TO-TEST-CONFIGURATION-INFO.txt
Select-String -Path "BOT-TO-TEST-CONFIGURATION-INFO.txt" -Pattern "TTS_SERVICE"
```

## Test Commands

### Test 1: Quick Test with 1 Utterance (Recommended First Test)
```powershell
# Generate audio for only 1 utterance (12 audio files: 6 accents × 2 genders)
# Skip Dialogflow testing to focus on TTS generation only
python main.py sample-utterance.xlsx --limit 1 --skip-testing
```

### Test 2: Test with Custom Output Directory
```powershell
# Use a separate output directory for testing
python main.py sample-utterance.xlsx --limit 1 --output-dir google-tts-test --skip-testing
```

### Test 3: Verify Generated Audio Files
```powershell
# Check that audio files were created
Get-ChildItem -Path "test-output\original\utterance_1" -Filter "*.mp3"
Get-ChildItem -Path "test-output\dialogflow-ready\utterance_1" -Filter "*.wav"

# Count files (should be 12 files in each directory)
(Get-ChildItem -Path "test-output\original\utterance_1" -Filter "*.mp3").Count
(Get-ChildItem -Path "test-output\dialogflow-ready\utterance_1" -Filter "*.wav").Count
```

### Test 4: Check Voice Mapping
```powershell
# View the voice mapping that was discovered
Get-Content "test-output\voice_mapping.json" | ConvertFrom-Json | ConvertTo-Json -Depth 10
```

### Test 5: View TTS Generation Results
```powershell
# Check the results CSV
Import-Csv "test-output\tts_generation_results.csv" | Format-Table
```

## Troubleshooting

### If Google TTS Fails with Credentials Error:

**The code now automatically uses the service account key from your config file (same as Dialogflow).**

Make sure:
1. Your `BOT-TO-TEST-CONFIGURATION-INFO.txt` has the correct `CREDS_PATH` pointing to your service account JSON key file
2. The service account has **Text-to-Speech API** permissions enabled
3. The Text-to-Speech API is enabled in your Google Cloud project

If you still get authentication errors:
```powershell
# Option 1: Verify the credentials path in config file
Select-String -Path "BOT-TO-TEST-CONFIGURATION-INFO.txt" -Pattern "CREDS_PATH"

# Option 2: Verify the file exists
Test-Path "path\to\your\service-account-key.json"

# Option 3: If using gcloud application-default credentials (not recommended), reauthenticate:
gcloud auth application-default login
```

### If Google TTS Library is Not Installed:
```powershell
pip install google-cloud-texttospeech
```

### If You Want to Test Edge TTS Instead (for comparison):
```powershell
# Edit BOT-TO-TEST-CONFIGURATION-INFO.txt and set:
# TTS_SERVICE = "edge"
# Then run:
python main.py sample-utterance.xlsx --limit 1 --skip-testing
```

### Verify Google Cloud Text-to-Speech API is Enabled:
```powershell
# Test with explicit credentials (update path to your service account key)
python -c "from google.cloud import texttospeech; from google.oauth2 import service_account; creds = service_account.Credentials.from_service_account_file('path/to/your/service-account-key.json'); client = texttospeech.TextToSpeechClient(credentials=creds); voices = client.list_voices(); print(f'Found {len(voices.voices)} voices')"
```

**Note:** The script automatically uses the credentials from your config file, so you don't need to test manually. Just run the main script.

## Expected Output

When Google TTS is working correctly, you should see:
1. ✅ "Discovering available Google TTS voices..." message
2. ✅ Voice mapping for all 6 accents × 2 genders (12 voices total)
3. ✅ "Generating audio files" with progress for each voice
4. ✅ 12 MP3 files in `test-output/original/utterance_1/`
5. ✅ 12 WAV files in `test-output/dialogflow-ready/utterance_1/`
6. ✅ Success messages for each file generation

## Clean Up Test Files (Optional)
```powershell
# Remove test output directory if you want to start fresh
Remove-Item -Path "test-output" -Recurse -Force
```

