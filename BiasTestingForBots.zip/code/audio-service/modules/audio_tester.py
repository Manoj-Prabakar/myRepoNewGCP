"""
Audio Testing Module
Tests audio files with Dialogflow CX and records results

PROPRIETARY NOTICE:
This code is proprietary and belongs to Miratech.
Copyright (c) Miratech. All rights reserved.
Contact: Nikhil.Kodilkar@gmail.com
"""

import json
from pathlib import Path
from modules.dialogflow_client import DialogflowClient


def find_audio_files(audio_dir):
    """
    Find all audio files organized by utterance
    
    Returns:
        dict: {utterance_id: [list of audio file paths]}
    """
    audio_dir = Path(audio_dir)
    print(f"[DEBUG] Searching for audio files in: {audio_dir}")
    
    if not audio_dir.exists():
        print(f"[ERROR] Audio directory does not exist: {audio_dir}")
        return {}
    
    audio_files = {}
    
    # Look for utterance_X directories
    utterance_dirs = list(audio_dir.glob("utterance_*"))
    print(f"[DEBUG] Found {len(utterance_dirs)} utterance directories")
    
    for utterance_dir in sorted(utterance_dirs):
        utterance_id = utterance_dir.name.replace("utterance_", "")
        print(f"[DEBUG] Processing utterance directory: {utterance_dir.name} (ID: {utterance_id})")
        
        # Find all WAV files in this directory
        wav_files = list(utterance_dir.glob("*.wav"))
        print(f"[DEBUG] Found {len(wav_files)} WAV files in {utterance_dir.name}")
        
        if wav_files:
            audio_files[utterance_id] = []
            for wav_file in sorted(wav_files):
                # Parse file name: {id}_{gender}_{accent}.wav
                parts = wav_file.stem.split('_')
                if len(parts) >= 3:
                    file_id = parts[0]
                    gender = parts[1]
                    accent = '_'.join(parts[2:])  # Handle multi-word accents
                    
                    audio_files[utterance_id].append({
                        'file_path': str(wav_file),
                        'utterance_id': file_id,
                        'gender': gender,
                        'accent': accent,
                        'filename': wav_file.name
                    })
                else:
                    print(f"[WARNING] Could not parse filename: {wav_file.name}")
    
    print(f"[DEBUG] Total audio files found: {sum(len(files) for files in audio_files.values())}")
    return audio_files


def test_audio_files(dialogflow_client, audio_dir, start_with_greeting=False, 
                    flow_id=None, page_id=None):
    """
    Test all audio files with Dialogflow CX
    
    Args:
        dialogflow_client: DialogflowClient instance
        audio_dir: Directory containing audio files (organized by utterance)
        start_with_greeting: Whether to start conversations with greeting
        flow_id: Optional flow ID
        page_id: Optional page ID
    
    Returns:
        dict with test results
    """
    if dialogflow_client is None:
        print("[ERROR] Dialogflow client is None")
        return None
    
    print("  Finding audio files...")
    audio_files = find_audio_files(audio_dir)
    
    if not audio_files:
        print("  ❌ No audio files found")
        print(f"[ERROR] No audio files found in: {audio_dir}")
        return None
    
    total_files = sum(len(files) for files in audio_files.values())
    print(f"  ✓ Found {total_files} audio files across {len(audio_files)} utterances")
    print()
    
    all_results = []
    current_file = 0
    
    # Sort utterance IDs, handling non-numeric IDs gracefully
    def sort_key(x):
        try:
            return int(x[0])
        except ValueError:
            return x[0]
    
    for utterance_id, files in sorted(audio_files.items(), key=sort_key):
        print(f"  Testing Utterance {utterance_id} ({len(files)} audio files)...")
        print(f"[DEBUG] Processing utterance {utterance_id} with {len(files)} files")
        
        for file_info in files:
            current_file += 1
            audio_path = file_info['file_path']
            
            print(f"    [{current_file}/{total_files}] Testing: {file_info['filename']}")
            print(f"      Accent: {file_info['accent']}, Gender: {file_info['gender']}")
            print(f"[DEBUG] Audio file path: {audio_path}")
            print(f"      Processing...", end=" ", flush=True)
            
            try:
                result = dialogflow_client.test_audio_file(
                    audio_file_path=audio_path,
                    start_with_greeting=start_with_greeting,
                    flow_id=flow_id,
                    page_id=page_id
                )
                
                print(f"[DEBUG] Dialogflow response received: success={result.get('success', False)}")
                
                if result['success']:
                    print("✓")
                    print(f"      Transcript: '{result['transcript']}'")
                    print(f"      Intent: {result['intent']['name']} (confidence: {result['confidence']:.2f})")
                    print("")
                    
                    all_results.append({
                        'utterance_id': file_info['utterance_id'],
                        'accent': file_info['accent'],
                        'gender': file_info['gender'],
                        'audio_file': file_info['filename'],
                        'transcript': result['transcript'],
                        'response_text': result['response_text'],
                        'detected_intent': result['intent']['name'],
                        'intent_confidence': result['confidence'],
                        'headIntent': result['parameters']['headIntent'],
                        'subIntent': result['parameters']['subIntent'],
                        'caller_type': result['parameters']['caller_type'],
                        'payments_query_type': result['parameters']['payments_query_type'],
                        'benefits_type': result['parameters']['benefits_type'],
                        'status': 'success'
                    })
                else:
                    print("✗ FAILED")
                    print(f"      Error: {result.get('error', 'Unknown error')}")
                    print("")
                    
                    all_results.append({
                        'utterance_id': file_info['utterance_id'],
                        'accent': file_info['accent'],
                        'gender': file_info['gender'],
                        'audio_file': file_info['filename'],
                        'status': 'error',
                        'error': result.get('error', 'Unknown error')
                    })
            
            except Exception as e:
                print("✗ FAILED")
                print(f"      Error: {str(e)}")
                print("")
                
                all_results.append({
                    'utterance_id': file_info['utterance_id'],
                    'accent': file_info['accent'],
                    'gender': file_info['gender'],
                    'audio_file': file_info['filename'],
                    'status': 'error',
                    'error': str(e)
                })
    
    successful = len([r for r in all_results if r['status'] == 'success'])
    
    return {
        'total_tested': len(all_results),
        'successful': successful,
        'failed': len(all_results) - successful,
        'results': all_results
    }

