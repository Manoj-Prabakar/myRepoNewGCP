"""
Report Generation Module
Generates Excel report comparing input utterances with Dialogflow results

PROPRIETARY NOTICE:
This code is proprietary and belongs to Miratech.
Copyright (c) Miratech. All rights reserved.
Contact: Nikhil.Kodilkar@gmail.com
"""

import pandas as pd
from pathlib import Path
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


def generate_report(tts_results, test_results, output_dir, excel_path):
    """
    Generate Excel report with comparison and pass percentage
    
    Args:
        tts_results: Results from TTS generation
        test_results: Results from Dialogflow testing
        output_dir: Output directory for report
        excel_path: Original Excel file path (to get input utterances)
    
    Returns:
        Path to generated report file
    """
    print("  Loading input utterances...")
    print(f"[DEBUG] Excel path: {excel_path}")
    print(f"[DEBUG] Output directory: {output_dir}")
    
    output_dir = Path(output_dir)
    if not output_dir.exists():
        print(f"[ERROR] Output directory does not exist: {output_dir}")
        return None
    
    # Load original Excel to get input utterances
    excel_path = Path(excel_path)
    if not excel_path.exists():
        print(f"[ERROR] Excel file does not exist: {excel_path}")
        return None
    
    try:
        print(f"[DEBUG] Reading Excel file: {excel_path}")
        df_input = pd.read_excel(excel_path, sheet_name=0)
        print(f"[DEBUG] Loaded {len(df_input)} rows from Excel")
    except Exception as e:
        print(f"[ERROR] Failed to read Excel file: {e}")
        return None
    
    # Create results DataFrame
    if not test_results or 'results' not in test_results:
        print("  ❌ Error: No test results found")
        return None
    
    test_df = pd.DataFrame(test_results['results'])
    
    if test_df.empty:
        print("  ❌ Error: Test results are empty")
        return None
    
    # Merge with input utterances
    report_data = []
    
    for _, test_row in test_df.iterrows():
        try:
            utterance_id = int(test_row.get('utterance_id', 0))
            
            # Get original utterance text
            if utterance_id > 0 and utterance_id <= len(df_input):
                original_utterance = str(df_input.iloc[utterance_id - 1]['Utterance']).strip()
            else:
                original_utterance = 'N/A'
            
            report_data.append({
                'Utterance_ID': utterance_id,
                'Original_Utterance': original_utterance,
                'Audio_Variant': f"{test_row.get('gender', 'unknown')}_{test_row.get('accent', 'unknown')}",
                'Gender': test_row.get('gender', ''),
                'Accent': test_row.get('accent', ''),
                'Audio_File': test_row.get('audio_file', ''),
                'Transcript': test_row.get('transcript', ''),
                'Detected_Intent': test_row.get('detected_intent', ''),
                'Intent_Confidence': test_row.get('intent_confidence', 0),
                'HeadIntent': test_row.get('headIntent', ''),
                'SubIntent': test_row.get('subIntent', ''),
                'Caller_Type': test_row.get('caller_type', ''),
                'Response_Text': test_row.get('response_text', ''),
                'Status': test_row.get('status', 'error')
            })
        except Exception as e:
            print(f"  ⚠ Warning: Error processing test row: {e}")
            continue
    
    report_df = pd.DataFrame(report_data)
    
    # Calculate pass percentage
    # For now, we'll consider it a "pass" if Dialogflow returned a response
    # You can customize this logic based on your requirements
    total_tests = len(report_df)
    passed_tests = len(report_df[report_df['Status'] == 'success'])
    pass_percentage = (passed_tests / total_tests * 100) if total_tests > 0 else 0
    
    # Generate summary statistics
    summary_data = {
        'Metric': [
            'Total Audio Files Tested',
            'Successful Tests',
            'Failed Tests',
            'Pass Percentage (%)',
            'Total Utterances',
            'Variants per Utterance'
        ],
        'Value': [
            total_tests,
            passed_tests,
            total_tests - passed_tests,
            f"{pass_percentage:.2f}%",
            len(report_df['Utterance_ID'].unique()),
            12
        ]
    }
    summary_df = pd.DataFrame(summary_data)
    
    # Save to Excel with formatting
    report_path = Path(output_dir) / 'test_report.xlsx'
    print(f"[DEBUG] Report path: {report_path}")
    
    try:
        with pd.ExcelWriter(report_path, engine='openpyxl') as writer:
            # Write summary sheet
            summary_df.to_excel(writer, sheet_name='Summary', index=False)
            
            # Write detailed results
            report_df.to_excel(writer, sheet_name='Detailed Results', index=False)
            
            # Write per-accent summary
            accent_summary = report_df.groupby('Accent').agg({
                'Status': lambda x: (x == 'success').sum(),
                'Utterance_ID': 'count'
            }).reset_index()
            accent_summary.columns = ['Accent', 'Passed', 'Total']
            accent_summary['Pass_Percentage'] = (accent_summary['Passed'] / accent_summary['Total'] * 100).round(2)
            accent_summary.to_excel(writer, sheet_name='Accent Summary', index=False)
            
            # Write per-gender summary
            gender_summary = report_df.groupby('Gender').agg({
                'Status': lambda x: (x == 'success').sum(),
                'Utterance_ID': 'count'
            }).reset_index()
            gender_summary.columns = ['Gender', 'Passed', 'Total']
            gender_summary['Pass_Percentage'] = (gender_summary['Passed'] / gender_summary['Total'] * 100).round(2)
            gender_summary.to_excel(writer, sheet_name='Gender Summary', index=False)
            
            print(f"[DEBUG] Excel file created with {len(writer.sheets)} sheets")
    except Exception as e:
        print(f"[ERROR] Failed to write Excel file: {e}")
        import traceback
        traceback.print_exc()
        return None
    
    # Apply formatting
    print(f"[DEBUG] Applying formatting to Excel file...")
    try:
        wb = load_workbook(report_path)
    except Exception as e:
        print(f"[ERROR] Failed to load workbook for formatting: {e}")
        return report_path  # Return path even if formatting fails
    
    # Format Summary sheet
    ws_summary = wb['Summary']
    ws_summary['A1'].font = Font(bold=True, size=12)
    ws_summary['B1'].font = Font(bold=True, size=12)
    for col in ['A', 'B']:
        ws_summary.column_dimensions[col].width = 25
    
    # Format Detailed Results sheet
    ws_details = wb['Detailed Results']
    header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF")
    
    for cell in ws_details[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center')
    
    # Auto-adjust column widths
    for column in ws_details.columns:
        max_length = 0
        column_letter = get_column_letter(column[0].column)
        for cell in column:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
        adjusted_width = min(max_length + 2, 50)
        ws_details.column_dimensions[column_letter].width = adjusted_width
    
    # Highlight failed tests
    red_fill = PatternFill(start_color="FFCCCC", end_color="FFCCCC", fill_type="solid")
    for row in ws_details.iter_rows(min_row=2, max_row=ws_details.max_row):
        status_cell = row[12]  # Status column
        if status_cell.value == 'error':
            for cell in row:
                cell.fill = red_fill
    
    try:
        wb.save(report_path)
        print(f"[DEBUG] Formatting applied and file saved")
    except Exception as e:
        print(f"[WARNING] Failed to save formatted workbook: {e}")
        # File might still be usable without formatting
    
    print(f"  ✓ Report generated: {report_path.name}")
    print(f"    Total tests: {total_tests}")
    print(f"    Passed: {passed_tests}")
    print(f"    Pass percentage: {pass_percentage:.2f}%")
    print(f"[DEBUG] Report generation complete: {report_path}")
    
    return report_path

