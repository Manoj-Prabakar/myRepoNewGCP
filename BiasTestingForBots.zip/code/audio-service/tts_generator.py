"""
TTS Audio Generator for Dialogflow CX Testing
Generates 12 audio variations per utterance (2 genders × 6 accents)
python audio-service/tts_generator.py sample-utterence.xlsx --output-dir test-audio-output --limit 1

PROPRIETARY NOTICE:
This code is proprietary and belongs to Miratech.
Copyright (c) Miratech. All rights reserved.
Contact: Nikhil.Kodilkar@gmail.com
"""

import os
import sys
import pandas as pd
import asyncio
import edge_tts
from pathlib import Path
import json

# Fix Windows console encoding for emojis
if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except:
        pass  # If reconfigure fails, continue without emojis

# Try to import pydub, fallback to soundfile if audioop issue
try:
    from pydub import AudioSegment
    USE_PYDUB = True
except (ImportError, ModuleNotFoundError) as e:
    if 'audioop' in str(e) or 'pyaudioop' in str(e):
        # Python 3.13 removed audioop - use soundfile instead
        try:
            import soundfile as sf
            import numpy as np
            USE_PYDUB = False
            print("Note: Using soundfile instead of pydub (Python 3.13 compatibility)")
        except ImportError:
            print("Error: Need either pydub (with audioop) or soundfile installed")
            print("Install soundfile: pip install soundfile")
            sys.exit(1)
    else:
        raise

# Configuration
ACCENTS = [
    'indian_english',
    'french_english', 
    'chinese_english',
    'spanish_english',
    'african_english',
    'regular_english'
]

GENDERS = ['male', 'female']

# Voice mapping - will be populated after discovering available voices
VOICE_MAP = {}

# Output directories
OUTPUT_DIR = Path('generated-audio')
ORIGINAL_DIR = OUTPUT_DIR / 'original'  # Original Edge TTS output
DIALOGFLOW_DIR = OUTPUT_DIR / 'dialogflow-ready'  # Converted for Dialogflow


async def discover_voices():
    """Discover available Edge TTS voices and map them to our accent/gender requirements"""
    print("="*60)
    print("🔍 Discovering available Edge TTS voices...")
    print("="*60)
    
    print("  Connecting to Edge TTS service...", end=" ", flush=True)
    voices = await edge_tts.list_voices()
    print(f"✓ Found {len(voices)} total voices")
    
    # Map voices to our requirements
    # This is a simplified mapping - you may need to adjust based on actual available voices
    voice_mapping = {
        'indian_english': {
            'male': None,
            'female': None
        },
        'french_english': {
            'male': None,
            'female': None
        },
        'chinese_english': {
            'male': None,
            'female': None
        },
        'spanish_english': {
            'male': None,
            'female': None
        },
        'african_english': {
            'male': None,
            'female': None
        },
        'regular_english': {
            'male': None,
            'female': None
        }
    }
    
    # Filter voices by language (English) and try to match accents
    english_voices = [v for v in voices if v['Locale'].startswith('en')]
    
    print(f"\n  📊 Found {len(english_voices)} English voices")
    print("\n  Available English voices by locale:")
    
    # Group voices by locale for better visibility
    locale_groups = {}
    for voice in english_voices:
        locale = voice['Locale']
        if locale not in locale_groups:
            locale_groups[locale] = []
        locale_groups[locale].append(voice)
    
    for locale in sorted(locale_groups.keys())[:15]:  # Show first 15 locales
        voices_in_locale = locale_groups[locale]
        print(f"    {locale}: {len(voices_in_locale)} voices")
        for v in voices_in_locale[:3]:  # Show first 3 per locale
            print(f"      - {v['ShortName']:30s} ({v['Gender']})")
        if len(voices_in_locale) > 3:
            print(f"      ... and {len(voices_in_locale) - 3} more")
    
    # Also check for Spanish, French, Chinese voices (for accent purposes)
    spanish_voices = [v for v in voices if 'es-' in v['Locale'].lower() or 'es_' in v['Locale'].lower()]
    french_voices = [v for v in voices if 'fr-' in v['Locale'].lower() or 'fr_' in v['Locale'].lower()]
    chinese_voices = [v for v in voices if 'zh-' in v['Locale'].lower() or 'cn-' in v['Locale'].lower()]
    
    if spanish_voices:
        print(f"\n  Found {len(spanish_voices)} Spanish voices (for accent):")
        # Show es-US and es-MX voices specifically (best for Spanish-accented English)
        es_us_mx = [v for v in spanish_voices if 'es-US' in v['Locale'] or 'es-MX' in v['Locale']]
        if es_us_mx:
            print(f"    Spanish US/Mexico voices (best for Spanish-accented English):")
            for v in es_us_mx[:6]:
                multilingual = " [Multilingual]" if 'Multilingual' in v.get('ShortName', '') else ""
                print(f"      - {v['ShortName']:30s} | {v['Gender']:6s} | {v['Locale']}{multilingual}")
        else:
            for v in spanish_voices[:5]:
                print(f"      - {v['ShortName']:30s} | {v['Gender']:6s} | {v['Locale']}")
    
    print("\n  🔗 Mapping voices to accents based on locale...")
    
    # Map accents to locale codes
    accent_locale_map = {
        'indian_english': {'search_in': 'english', 'locales': ['en-IN']},  # Indian English
        'french_english': {'search_in': 'both', 'locales': ['en-FR', 'fr-FR', 'fr-CA']},  # French English or French (for accent)
        'chinese_english': {'search_in': 'both', 'locales': ['en-CN', 'zh-CN', 'zh-HK']},  # Chinese English or Chinese (for accent)
        'spanish_english': {'search_in': 'both', 'locales': ['es-US', 'es-MX', 'en-ES', 'es-ES']},  # Spanish US/Mexico (Spanish-accented English) preferred
        'african_english': {'search_in': 'english', 'locales': ['en-ZA', 'en-NG', 'en-KE']},  # South African, Nigerian, Kenyan English
        'regular_english': {'search_in': 'english', 'locales': ['en-US', 'en-GB', 'en-AU', 'en-CA']}  # Standard English variants
    }
    
    # Track which voices we've used to avoid duplicates
    used_voices = set()
    fallback_count = 0
    
    # Map each accent to appropriate voices
    for accent_key in voice_mapping.keys():
        accent_config = accent_locale_map.get(accent_key, {'search_in': 'english', 'locales': ['en-US']})
        target_locales = accent_config['locales']
        search_in = accent_config['search_in']
        
        # Determine which voice list to search
        if search_in == 'english':
            voice_list = english_voices
        elif search_in == 'both':
            # For Spanish/French/Chinese, search in both English and native language voices
            if accent_key == 'spanish_english':
                voice_list = english_voices + spanish_voices
            elif accent_key == 'french_english':
                voice_list = english_voices + french_voices
            elif accent_key == 'chinese_english':
                voice_list = english_voices + chinese_voices
            else:
                voice_list = english_voices
        else:
            voice_list = english_voices
        
        for gender in ['Male', 'Female']:
            voice_found = False
            
            # Try to find voice in target locales
            for target_locale in target_locales:
                matching_voices = [
                    v for v in voice_list 
                    if v['Gender'] == gender 
                    and target_locale in v['Locale']
                    and v['ShortName'] not in used_voices
                ]
                
                # For Spanish, prefer multilingual voices if available (they can speak English)
                if accent_key == 'spanish_english' and matching_voices:
                    multilingual = [v for v in matching_voices if 'Multilingual' in v.get('ShortName', '')]
                    if multilingual:
                        matching_voices = multilingual
                        print(f"      (Using multilingual voice for better English support)")
                
                if matching_voices:
                    selected_voice = matching_voices[0]
                    voice_mapping[accent_key][gender.lower()] = selected_voice['ShortName']
                    used_voices.add(selected_voice['ShortName'])
                    print(f"    ✓ {accent_key:20s} {gender.lower():6s} → {selected_voice['ShortName']:30s} ({selected_voice['Locale']})")
                    voice_found = True
                    break
            
            # Fallback: Use any available English voice if specific locale not found
            if not voice_found:
                fallback_voices = [
                    v for v in english_voices 
                    if v['Gender'] == gender 
                    and v['ShortName'] not in used_voices
                ]
                
                if fallback_voices:
                    selected_voice = fallback_voices[0]
                    voice_mapping[accent_key][gender.lower()] = selected_voice['ShortName']
                    used_voices.add(selected_voice['ShortName'])
                    print(f"    ⚠ {accent_key:20s} {gender.lower():6s} → {selected_voice['ShortName']:30s} ({selected_voice['Locale']}) [FALLBACK]")
                    fallback_count += 1
    
    if fallback_count > 0:
        print(f"\n  ⚠ Warning: Used {fallback_count} fallback voices (specific accent not available)")
    
    print("")
    return voice_mapping


async def generate_audio(text, voice_name, output_path):
    """Generate audio file using Edge TTS"""
    try:
        communicate = edge_tts.Communicate(text, voice_name)
        await communicate.save(str(output_path))
        return True
    except Exception as e:
        print(f"\n      ❌ Error: {str(e)}")
        return False


def convert_to_dialogflow_format(input_path, output_path):
    """Convert audio to Dialogflow-compatible format (16kHz, mono, 16-bit PCM WAV)"""
    try:
        if USE_PYDUB:
            # Use pydub (if available)
            audio = AudioSegment.from_file(str(input_path))
            
            # Convert to mono if stereo
            if audio.channels > 1:
                audio = audio.set_channels(1)
            
            # Resample to 16kHz
            audio = audio.set_frame_rate(16000)
            
            # Set sample width to 2 bytes (16-bit)
            audio = audio.set_sample_width(2)
            
            # Export as WAV
            audio.export(str(output_path), format="wav")
        else:
            # Use soundfile (Python 3.13 compatible)
            import soundfile as sf
            import numpy as np
            from scipy import signal
            
            # Read audio file
            data, sample_rate = sf.read(str(input_path))
            
            # Convert to mono if stereo
            if len(data.shape) > 1 and data.shape[1] > 1:
                data = np.mean(data, axis=1)
            
            # Resample to 16kHz if needed
            if sample_rate != 16000:
                num_samples = int(len(data) * 16000 / sample_rate)
                data = signal.resample(data, num_samples)
                sample_rate = 16000
            
            # Ensure 16-bit PCM format
            # Normalize to [-1, 1] range and convert to int16
            if data.dtype != np.int16:
                # Normalize to prevent clipping
                max_val = np.abs(data).max()
                if max_val > 0:
                    data = data / max_val
                # Convert to int16 range
                data = (data * 32767).astype(np.int16)
            
            # Write as WAV file (16kHz, mono, 16-bit PCM)
            sf.write(str(output_path), data, 16000, subtype='PCM_16', format='WAV')
        
        return True
    except Exception as e:
        print(f"\n      ❌ Conversion error: {str(e)}")
        return False


async def generate_utterance_variations(utterance_id, utterance_text, voice_map):
    """Generate all 12 variations (2 genders × 6 accents) for a single utterance
    
    Generates:
    - 6 accents: Indian English, French English, Chinese English, 
                 Spanish English, African English, Regular English
    - 2 genders: Male, Female
    - Total: 12 audio files per utterance
    """
    results = []
    total_variations = len(ACCENTS) * len(GENDERS)
    current_file = 0
    
    print(f"  Generating {total_variations} voice variations (6 accents × 2 genders)...")
    print(f"  Utterance ID: {utterance_id}")
    print(f"  Text to generate: '{utterance_text}'")
    print(f"  Text length: {len(utterance_text)} characters")
    print("")
    
    for accent in ACCENTS:
        for gender in GENDERS:
            current_file += 1
            voice_name = voice_map.get(accent, {}).get(gender)
            
            if not voice_name:
                print(f"  [{current_file}/{total_variations}] ⚠ SKIPPED: {accent.upper()} {gender.upper()} - No voice found")
                results.append({
                    'utterance_id': utterance_id,
                    'accent': accent,
                    'gender': gender,
                    'voice': 'N/A',
                    'status': 'voice_not_found'
                })
                continue
            
            # Create directory structure
            utterance_dir = ORIGINAL_DIR / f"utterance_{utterance_id}"
            utterance_dir.mkdir(parents=True, exist_ok=True)
            
            dialogflow_dir = DIALOGFLOW_DIR / f"utterance_{utterance_id}"
            dialogflow_dir.mkdir(parents=True, exist_ok=True)
            
            # File paths
            original_file = utterance_dir / f"{utterance_id}_{gender}_{accent}.mp3"
            dialogflow_file = dialogflow_dir / f"{utterance_id}_{gender}_{accent}.wav"
            
            # Generate audio
            print(f"  [{current_file}/{total_variations}] 🎤 Generating: {accent.upper()} {gender.upper()}")
            print(f"      Voice: {voice_name}")
            print(f"      Text: '{utterance_text}'")
            print(f"      Creating audio file...", end=" ", flush=True)
            
            success = await generate_audio(utterance_text, voice_name, original_file)
            
            if success:
                # Get file size
                file_size_kb = original_file.stat().st_size / 1024
                print(f"✓ ({file_size_kb:.1f} KB)")
                
                # Convert to Dialogflow format
                print(f"      Converting to Dialogflow format...", end=" ", flush=True)
                convert_success = convert_to_dialogflow_format(original_file, dialogflow_file)
                
                if convert_success:
                    dialogflow_size_kb = dialogflow_file.stat().st_size / 1024
                    print(f"✓ ({dialogflow_size_kb:.1f} KB)")
                    print(f"      ✓ Saved: {dialogflow_file.name}")
                    print("")
                    
                    results.append({
                        'utterance_id': utterance_id,
                        'accent': accent,
                        'gender': gender,
                        'voice': voice_name,
                        'original_file': str(original_file),
                        'dialogflow_file': str(dialogflow_file),
                        'original_size_kb': round(file_size_kb, 2),
                        'dialogflow_size_kb': round(dialogflow_size_kb, 2),
                        'status': 'success'
                    })
                else:
                    print(f"✗ FAILED")
                    print(f"      Error: Audio conversion failed")
                    print("")
                    results.append({
                        'utterance_id': utterance_id,
                        'accent': accent,
                        'gender': gender,
                        'voice': voice_name,
                        'status': 'conversion_failed'
                    })
            else:
                print(f"✗ FAILED")
                print(f"      Error: Audio generation failed")
                print("")
                results.append({
                    'utterance_id': utterance_id,
                    'accent': accent,
                    'gender': gender,
                    'voice': voice_name,
                    'status': 'generation_failed'
                })
    
    successful_count = len([r for r in results if r['status'] == 'success'])
    print(f"  ✓ Completed: {successful_count}/{total_variations} files generated successfully")
    print("")
    
    return results


async def process_excel_file(excel_path, limit=None):
    """Process Excel file and generate audio files for all utterances"""
    
    # Get limit from args if available
    if hasattr(process_excel_file, 'args'):
        limit = process_excel_file.args.limit
    
    # Read Excel file
    print("="*60)
    print("📄 LOADING EXCEL FILE")
    print("="*60)
    try:
        print(f"  Reading file: {excel_path}")
        print(f"  Absolute path: {excel_path.absolute()}")
        print(f"  File exists: {excel_path.exists()}")
        
        # Try reading with header=None first to see raw data
        df_raw = pd.read_excel(excel_path, sheet_name=0, header=None, nrows=10)
        print(f"\n  Raw first 5 rows (no header):")
        for i in range(min(5, len(df_raw))):
            print(f"    Row {i}: {df_raw.iloc[i].tolist()}")
        
        # Now read with proper header detection
        df = pd.read_excel(excel_path, sheet_name=0)
        print(f"\n  ✓ Loaded successfully")
        print(f"  Total rows in DataFrame: {len(df)}")
        print(f"  Columns: {df.columns.tolist()}")
        
        # Show ALL rows if file is small (less than 10 rows)
        if len(df) <= 10:
            print(f"\n  ⚠ File has {len(df)} row(s) - showing ALL data:")
            for i in range(len(df)):
                if 'Utterance' in df.columns:
                    print(f"    Row {i}: '{df.iloc[i]['Utterance']}'")
                else:
                    print(f"    Row {i}: {df.iloc[i].to_dict()}")
        
        # Check if first row might be a header
        first_val = str(df.iloc[0]['Utterance']).strip().lower() if 'Utterance' in df.columns else ''
        if first_val in ['utterance', 'utterances', 'text', 'sentence']:
            print(f"  ⚠ WARNING: First row appears to be a header: '{df.iloc[0]['Utterance']}'")
            print(f"  Will skip first row if it looks like a header")
        
        # Show first few utterances for verification
        if len(df) <= 10:
            print(f"\n  All {len(df)} utterance(s) in Excel file:")
            for i in range(len(df)):
                if 'Utterance' in df.columns:
                    utterance_val = df.iloc[i]['Utterance']
                    print(f"    Row {i+1}: '{utterance_val}'")
        else:
            print(f"\n  First 10 utterances in Excel file (pandas index shown):")
            for i in range(min(10, len(df))):
                if 'Utterance' in df.columns:
                    utterance_val = df.iloc[i]['Utterance']
                    print(f"    Pandas index {i} (Excel row {i+2} if header exists): '{utterance_val}'")
            if len(df) > 10:
                print(f"    ... and {len(df) - 10} more utterance(s)")
        
        # Count valid utterances
        valid_utterances = df[df['Utterance'].notna() & (df['Utterance'].astype(str).str.strip() != '')]
        print(f"\n  Valid utterances: {len(valid_utterances)}")
        print(f"  Expected audio files: {len(valid_utterances) * 12} (12 per utterance)")
    except Exception as e:
        print(f"  ❌ Error reading Excel file: {e}")
        return
    
    # Check for 'Utterance' column
    if 'Utterance' not in df.columns:
        print("  ❌ Error: 'Utterance' column not found in Excel file")
        print(f"  Available columns: {df.columns.tolist()}")
        return
    
    print("")
    
    # Discover available voices
    print("\n" + "="*60)
    voice_map = await discover_voices()
    
    # Save voice mapping for reference
    mapping_file = OUTPUT_DIR / 'voice_mapping.json'
    with open(mapping_file, 'w') as f:
        json.dump(voice_map, f, indent=2)
    print(f"\nVoice mapping saved to: {mapping_file}")
    
    # Process each utterance
    print("\n" + "="*60)
    print("🎵 GENERATING AUDIO FILES")
    print("="*60)
    
    all_results = []
    valid_df = df[df['Utterance'].notna() & (df['Utterance'].astype(str).str.strip() != '')]
    total_utterances = len(valid_df)
    
    # Apply limit if specified
    if limit and limit > 0:
        valid_df = valid_df.head(limit)
        total_utterances = len(valid_df)
        print(f"\n⚠ Limited to processing {total_utterances} utterance(s) (--limit={limit})")
    
    current_utterance = 0
    
    for idx, row in valid_df.iterrows():
        # Get the actual row number from the original dataframe (0-indexed)
        original_idx = df.index.get_loc(idx)
        utterance_id = current_utterance + 1
        utterance_text = str(row['Utterance']).strip()
        
        if not utterance_text or utterance_text.lower() == 'nan':
            print(f"\n⚠ Skipping utterance {utterance_id}: Empty text")
            continue
        
        current_utterance += 1
        print("\n" + "="*60)
        print(f"📝 UTTERANCE {utterance_id}/{total_utterances}")
        print("="*60)
        print(f"Excel Row Number: {original_idx + 1} (0-indexed: {original_idx})")
        print(f"Utterance ID: {utterance_id}")
        print(f"Utterance Text from Excel: '{utterance_text}'")
        print(f"Text Length: {len(utterance_text)} characters")
        print("")
        
        # Verify the text before generating
        if len(utterance_text) == 0:
            print("  ⚠ WARNING: Utterance text is empty, skipping...")
            continue
        
        results = await generate_utterance_variations(utterance_id, utterance_text, voice_map)
        all_results.extend(results)
        
        successful = len([r for r in results if r['status'] == 'success'])
        print(f"✓ Utterance {utterance_id} complete: {successful}/12 files generated")
        print(f"  Progress: {current_utterance}/{total_utterances} utterances processed")
        print("")
    
    # Save results summary
    results_df = pd.DataFrame(all_results)
    results_file = OUTPUT_DIR / 'generation_results.csv'
    results_df.to_csv(results_file, index=False)
    
    # Print summary
    print("\n" + "="*60)
    print("Generation Summary")
    print("="*60)
    successful = [r for r in all_results if r['status'] == 'success']
    failed = [r for r in all_results if r['status'] != 'success']
    
    utterances_processed = len(df[df['Utterance'].notna() & (df['Utterance'].astype(str).str.strip() != '')])
    expected_files = utterances_processed * 12  # 12 variations per utterance
    
    print(f"Utterances processed: {utterances_processed}")
    print(f"Expected files per utterance: 12 (6 accents × 2 genders)")
    print(f"Total expected files: {expected_files}")
    print(f"Successfully generated: {len(successful)}")
    print(f"Failed: {len(failed)}")
    
    if len(successful) > 0:
        success_rate = (len(successful) / expected_files) * 100
        print(f"Success rate: {success_rate:.1f}%")
    
    print(f"\nResults saved to: {results_file}")
    print(f"Audio files saved to: {OUTPUT_DIR}")
    print("\nDirectory structure:")
    print(f"  - Original files: {ORIGINAL_DIR}")
    print(f"  - Dialogflow-ready files: {DIALOGFLOW_DIR}")
    print("\nFile naming format:")
    print(f"  {utterances_processed if utterances_processed > 0 else 1}_{{gender}}_{{accent}}.wav")
    print(f"  Example: 1_male_indian.wav, 1_female_french.wav, etc.")


def main():
    """Main function"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Generate TTS audio files with multiple accents')
    parser.add_argument('excel_file', help='Path to Excel file with utterances')
    parser.add_argument('--output-dir', default='generated-audio', 
                       help='Output directory for generated audio files')
    parser.add_argument('--limit', type=int, default=None,
                       help='Limit number of utterances to process (for testing)')
    
    args = parser.parse_args()
    
    # Update output directory if specified
    global OUTPUT_DIR, ORIGINAL_DIR, DIALOGFLOW_DIR
    OUTPUT_DIR = Path(args.output_dir)
    ORIGINAL_DIR = OUTPUT_DIR / 'original'
    DIALOGFLOW_DIR = OUTPUT_DIR / 'dialogflow-ready'
    
    # Create output directories
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    ORIGINAL_DIR.mkdir(parents=True, exist_ok=True)
    DIALOGFLOW_DIR.mkdir(parents=True, exist_ok=True)
    
    # Check if Excel file exists - handle both absolute and relative paths
    excel_path_input = args.excel_file
    excel_path = None
    
    # Normalize Windows path separators
    excel_path_input = excel_path_input.replace('\\', os.sep).replace('/', os.sep)
    
    # Try multiple path resolution strategies - prioritize exact path first
    # IMPORTANT: If user provides a simple filename (no path), ONLY check current directory
    # Don't fall back to script directory - this causes confusion when wrong file is found
    
    # Check if it's a simple filename (no directory separators)
    is_simple_filename = (os.sep not in excel_path_input and 
                         '/' not in excel_path_input and 
                         '\\' not in excel_path_input and
                         not Path(excel_path_input).is_absolute())
    
    if is_simple_filename:
        # For simple filenames, ONLY check current working directory
        paths_to_try = [
            (Path.cwd() / excel_path_input).resolve(),  # From current working directory ONLY
        ]
    else:
        # For paths with directories, try multiple resolution strategies
        paths_to_try = [
            (Path.cwd() / excel_path_input).resolve(),  # From current working directory
            Path(excel_path_input).resolve(),  # Resolve from cwd as-is
            Path(excel_path_input),  # Direct path (relative to cwd)
            (Path(__file__).parent / excel_path_input).resolve(),  # From script directory
        ]
    
    # Debug: show what we're trying
    print(f"🔍 Looking for Excel file: {excel_path_input}")
    print(f"   Current directory: {Path.cwd()}")
    print(f"   Script directory: {Path(__file__).parent}")
    
    # Check for multiple files with same name
    matching_files = []
    for path in paths_to_try:
        if path.exists() and path.is_file():
            matching_files.append(path)
    
    if len(matching_files) > 1:
        print(f"\n   ⚠ WARNING: Found {len(matching_files)} files with similar name:")
        for f in matching_files:
            print(f"      - {f.absolute()} ({f.stat().st_size} bytes)")
        print(f"   Using: {matching_files[0].absolute()}")
        excel_path = matching_files[0]
    elif len(matching_files) == 1:
        excel_path = matching_files[0]
        print(f"   ✓ Found at: {excel_path.absolute()}")
    else:
        # If still not found, use the input as-is (will show error below)
        excel_path = Path(excel_path_input)
    
    if not excel_path.exists():
        print(f"❌ Error: Excel file not found: {args.excel_file}")
        print(f"   Resolved path: {excel_path.absolute()}")
        print(f"   Current working directory: {Path.cwd()}")
        print(f"   Script directory: {Path(__file__).parent}")
        
        # Suggest similar filenames
        parent_dir = Path(__file__).parent.parent
        if parent_dir.exists():
            xlsx_files = list(parent_dir.glob("*.xlsx"))
            if xlsx_files:
                print(f"\n   💡 Available Excel files in parent directory:")
                for f in xlsx_files:
                    print(f"      - {f.name}")
        
        return
    
    print(f"✓ Excel file found: {excel_path.absolute()}")
    print(f"   File size: {excel_path.stat().st_size} bytes")
    print(f"   Last modified: {excel_path.stat().st_mtime}")
    
    # Store limit in a way that process_excel_file can access it
    import types
    process_excel_file.args = types.SimpleNamespace(limit=args.limit)
    
    # Run the generation process
    asyncio.run(process_excel_file(excel_path))


if __name__ == '__main__':
    main()

