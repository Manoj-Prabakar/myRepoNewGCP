# =============================================================================
# Dialogflow CX NLU Accuracy Testing Script
# Author: Navaneso
# Date: October 2025
# Description: Tests Natural Language Understanding accuracy by simulating 
# conversations that start with a greeting to trigger the default start flow,
# then tests utterances from an Excel file against a Dialogflow CX agent.
# =============================================================================

# =============================================================================
# COLAB ENTERPRISE SETUP INSTRUCTIONS
# =============================================================================
# 1. Open Google Colab Enterprise (https://colab.research.google.com/)
# 2. Upload this notebook to your Colab environment
# 3. Upload your Excel file containing test utterances to the /content/ directory
# 4. For authentication, choose one of the options below in the AUTHENTICATION section
# 5. Update the configuration values in the CONFIGURATION SECTION
# 6. Run cells sequentially from top to bottom

# Install required dependencies - run these cells first in Colab
!pip install --upgrade --force-reinstall dfcx-scrapi

!pip install uuid

# Import required libraries for Dialogflow conversation testing
import os
import uuid
import pandas as pd
from dfcx_scrapi.core.conversation import DialogflowConversation

# =============================================================================
# AUTHENTICATION OPTIONS - Choose one of the following methods:
# =============================================================================
# Option 1: Service Account Key File (current method)
# - Create service account in Google Cloud Console
# - Download JSON key file and upload to your environment
# - Update YOUR_SERVICE_ACCOUNT_KEY_PATH below

# Option 2: gcloud Authentication (alternative method)
# - Run these commands before executing the script:
# !gcloud auth login
# !gcloud config set project YOUR_PROJECT_ID
# !gcloud auth application-default login
# - Then remove or comment out the 'creds_path' parameter in DialogflowConversation initialization

# =============================================================================
# CONFIGURATION SECTION - Update these values with your project details
# =============================================================================
YOUR_PROJECT_ID = "#####################"
YOUR_LOCATION_ID = "us-central1"
YOUR_AGENT_ID = "#####################"
YOUR_SERVICE_ACCOUNT_KEY_PATH = "/content/############.json"

# --- NEW: Flow/Page configuration for starting from a specific page ---
YOUR_FLOW_ID = "your-flow-id"      # Add your Flow ID here
YOUR_PAGE_ID = "your-page-id"      # Add your Page ID here

# --- NEW: Choose conversation start method ---
START_FROM_SPECIFIC_PAGE = True    # Set to False to start with greeting

# Construct the full agent resource name required by Dialogflow API
full_agent_resource_name = f"projects/{YOUR_PROJECT_ID}/locations/{YOUR_LOCATION_ID}/agents/{YOUR_AGENT_ID}"
PAGE_RESOURCE_NAME = f"{full_agent_resource_name}/flows/{YOUR_FLOW_ID}/pages/{YOUR_PAGE_ID}"
# =============================================================================
# DATA LOADING - Load test utterances from Excel file
# =============================================================================
try:
    # Load Excel file containing test utterances
    # Expected format: Excel file with a column named 'Utterance'
    df = pd.read_excel('/content/Caller_type_dataset.xlsx', sheet_name=0)    # Upload Excel file with utterances to test
    
    # Validate that the required 'Utterance' column exists
    if 'Utterance' not in df.columns:
        print("Error: 'Utterance' column not found.")
        exit()
except Exception as e:
    print(f"Error loading Excel file: {e}")
    exit()

# Initialize list to store all conversation results
results = []

print("\n--- Simulating Independent Conversations ---")

# =============================================================================
# MAIN TESTING LOOP - Process each utterance as a separate conversation
# =============================================================================
for i, utterance_from_excel in enumerate(df['Utterance'], start=1):
    print(f"\n--- Conversation #{i} ---")
    print(f"Utterance: '{utterance_from_excel}'")

    try:
        dc = DialogflowConversation(
            agent_id=full_agent_resource_name,
            creds_path=YOUR_SERVICE_ACCOUNT_KEY_PATH
        )
        print(f"Session ID: {dc.session_id}")

        if START_FROM_SPECIFIC_PAGE:
            # --- Option 1: Start from exact Flow/Page ---
            response = dc.reply(
                send_obj={'text': utterance_from_excel},
                current_page=PAGE_RESOURCE_NAME
            )
            results.append({
                'Conversation_ID': i,
                'Utterance_Type': 'ExcelUtterance_PageStart',
                'Utterance': utterance_from_excel,
                # ...extract and add other fields as before...
            })
        else:
            # --- Option 2: Start with greeting, then send utterance ---
            initial_utterance = "Hi"
            greeting_response = dc.reply(send_obj={'text': initial_utterance})
            greeting_texts = []

            # Extract text responses from the greeting interaction
            for msg in greeting_response.get('response_messages', []):
                if isinstance(msg, dict):
                    # Handle different response message formats from Dialogflow
                    if msg.get('message', {}).get('text', {}).get('text'):
                        greeting_texts.extend(msg['message']['text']['text'])
                    elif 'text' in msg:
                        greeting_texts.append(msg['text'])

            # Combine all greeting response texts or set default if none found
            bot_greeting = "\n".join(greeting_texts) if greeting_texts else 'NO_GREETING_RESPONSE'
            print(f"Greeting Response: '{bot_greeting}'")

            # Record the initial greeting interaction in results
            results.append({
                'Conversation_ID': i,
                'Utterance_Type': 'InitialGreeting',
                'Utterance': initial_utterance,
                'headIntent': 'InitialGreeting',
                'subIntent': '',
                'caller_type': '',
                'Response_Text': bot_greeting,
                'payments_query_type': '',
                'benefits_type': ''
            })

            response = dc.reply(send_obj={'text': utterance_from_excel})
            results.append({
                'Conversation_ID': i,
                'Utterance_Type': 'ExcelUtterance_GreetingStart',
                'Utterance': utterance_from_excel,
                # ...extract and add other fields as before...
            })

        # --- Extract response fields as in your original code ---
        response_texts = []
        for msg in response.get('response_messages', []):
            if isinstance(msg, dict):
                if msg.get('message', {}).get('text', {}).get('text'):
                    response_texts.extend(msg['message']['text']['text'])
                elif 'text' in msg:
                    response_texts.append(msg['text'])
        bot_response_text = "\n".join(response_texts) if response_texts else 'NO_RESPONSE_MESSAGES'
        params = response.get('params', {})
        headIntent = params.get('headIntent', 'unknown')
        subIntent = params.get('subIntent', 'unknown')
        caller_type = params.get('caller_type', 'unknown')
        payments_query_type = params.get('payments_query_type', '')
        benefits_type = params.get('benefits_type', '')

        print(f"Bot Response: '{bot_response_text}'")
        print(f"Intents: headIntent='{headIntent}', subIntent='{subIntent}', caller_type='{caller_type}'")

        # Update the last results entry with extracted fields
        results[-1].update({
            'headIntent': headIntent,
            'subIntent': subIntent,
            'caller_type': caller_type,
            'Response_Text': bot_response_text,
            'payments_query_type': payments_query_type,
            'benefits_type': benefits_type
        })

    except Exception as e:
        print(f"Error in conversation #{i}: {e}")
        results.append({
            'Conversation_ID': i,
            'Utterance_Type': 'Error',
            'Utterance': utterance_from_excel,
            'headIntent': 'ERROR',
            'subIntent': 'ERROR',
            'caller_type': 'ERROR',
            'Response_Text': f'ERROR: {e}',
            'payments_query_type': 'ERROR',
            'benefits_type': 'ERROR'
        })

# =============================================================================
# RESULTS EXPORT - Save all conversation results to CSV file
# =============================================================================
output_df = pd.DataFrame(results)
output_df.to_csv('Results.csv', index=False)                               # Change the name of output file with results
print("\nResults saved to 'Results.csv'")                                  # Change the name of output file with results